package com.example.Listviewproject;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Owner {


    private String login;

    public String getLogin() {
        return login;
    }

    }